/**
 * Field template: Qr Code
 */
Vue.component('form-qr_code', {
    template: '#tmpl-wpuf-form-qr_code',

    mixins: [
        wpuf_mixins.form_field_mixin
    ]
});
