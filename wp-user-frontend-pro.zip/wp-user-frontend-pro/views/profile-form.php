<div class="wrap">
    <?php do_action( 'wpuf-admin-form-builder' ); ?>
</div>
