<?php
$l['number'] 						= 'RÉfÉrence';
$l['date'] 							= 'Date de facturation';
$l['due'] 							= 'Date d\'échéance';
$l['to'] 							= 'Facturation à';
$l['from'] 							= 'Nos infos';
$l['product'] 						= 'Produit';
$l['amount'] 						= 'Montant';
$l['price'] 						= 'Prix';
$l['discount'] 						= 'Réduction';
$l['vat'] 							= 'Cuve';
$l['total'] 						= 'Total';
$l['page'] 							= 'Page';
$l['page_of'] 						= 'de';
?>