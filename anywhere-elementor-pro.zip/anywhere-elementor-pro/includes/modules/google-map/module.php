<?php

namespace Aepro\Modules\GoogleMap;

use Aepro\Base\ModuleBase;

class Module extends ModuleBase {

	public function get_widgets() {
		return [
			'ae-cf-google-map',
		];
	}

}