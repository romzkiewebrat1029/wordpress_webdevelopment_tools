<?php

namespace Aepro\Modules\AcfFlexibleContent;

use Aepro\Base\ModuleBase;

class Module extends ModuleBase {

	public function get_widgets() {
		return [
			'ae-acf-flexible-content',
		];
	}

}
