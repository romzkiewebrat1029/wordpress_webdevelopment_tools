Vue.component('field-math-captcha', {
    template: '#tmpl-wpuf-field-math-captcha',

    mixins: [
        wpuf_mixins.option_field_mixin
    ],
})
