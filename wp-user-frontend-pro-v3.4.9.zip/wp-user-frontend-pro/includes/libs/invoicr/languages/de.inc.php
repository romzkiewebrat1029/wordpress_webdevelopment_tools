<?php
$l['number'] 						= 'Referenz';
$l['date'] 							= 'Rechnungsdatum';
$l['due'] 							= 'Fälligkeitsdatum';
$l['to'] 							= 'Abrechnung';
$l['from'] 							= 'Unseren Informationen ';
$l['product'] 						= 'Produkt';
$l['amount'] 						= 'Menge';
$l['price'] 						= 'Preis';
$l['discount'] 						= 'Rabatt';
$l['vat'] 							= 'Steuer';
$l['total'] 						= 'Gesamt';
$l['page'] 							= 'Seite';
$l['page_of'] 						= 'von';
?>