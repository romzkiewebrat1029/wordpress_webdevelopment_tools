Booked WordPress Plugin
by Boxy Studio
http://codecanyon.net/user/boxystudio/portfolio

Have a look at the documentation (in the /Documentation/ folder) first thing, and enjoy the Booked WordPress plugin!